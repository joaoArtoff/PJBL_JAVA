package Testes;

import Excecoes.FaixaInvalidaException;
import Excecoes.PlayerException;
import Excecoes.PlaylistInvalidaException;
import Modelo.Biblioteca;
import Modelo.EpisodioPodcast;
import Modelo.Faixa;
import Modelo.Musica;
import Modelo.Playlist;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Exemplo de uso das classes do pacote Modelo, SEM interface gráfica.
 * Só um main que cria objetos, chama métodos e mostra o resultado no console.
 *
 * Cada "PARTE" demonstra um conceito da rubrica. Rode e compare a saída
 * com os comentários.
 */
public class ExemploUso {

    // Pasta onde vamos criar arquivos .mp3 de mentira (vazios) para o exemplo.
    // Como nada vai TOCAR aqui, o arquivo só precisa existir para passar na validação.
    private static final String PASTA = "exemplo-mp3";

    public static void main(String[] args) {
        try {
            prepararArquivosDeTeste();

            parte1CriandoObjetos();
            parte2Excecoes();
            Biblioteca biblioteca = parte3BibliotecaEPlaylists();
            parte4Polimorfismo(biblioteca);
            parte5PosicaoDoPodcast(biblioteca);
            parte6EncapsulamentoDaLista(biblioteca);

        } catch (PlayerException e) {
            // CATCH POLIMÓRFICO: pega FaixaInvalidaException E PlaylistInvalidaException,
            // porque as duas herdam de PlayerException.
            System.out.println("Erro inesperado no exemplo: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Não foi possível criar os arquivos de teste: " + e.getMessage());
        }
    }

    // =========================================================================
    // PARTE 1 — Criando objetos (classes e objetos, herança, super)
    // =========================================================================
    private static void parte1CriandoObjetos() throws FaixaInvalidaException {
        titulo("PARTE 1 - Criando músicas e podcasts");

        // new Musica(...) chama o construtor de Musica, que chama super(...) de Faixa.
        // A Faixa valida o título e o arquivo antes de o objeto existir.
        Musica m = new Musica("Bohemian Rhapsody", caminho("bohemian.mp3"), "Queen", "A Night at the Opera");
        System.out.println("Música criada: " + m);           // usa o toString() da Faixa

        // Artista e álbum vazios -> os setters colocam um valor padrão.
        Musica semInfo = new Musica("Faixa sem info", caminho("seminfo.mp3"), "", null);
        System.out.println("Sem artista/álbum: " + semInfo.getDescricao());

        EpisodioPodcast ep = new EpisodioPodcast("POO na prática", caminho("ep1.mp3"), "Café com Código", 1);
        System.out.println("Podcast criado: " + ep);

        // Faixa é ABSTRATA: a linha abaixo NEM COMPILA (descomente para ver o erro).
        // Faixa f = new Faixa("x", caminho("bohemian.mp3"));
    }

    // =========================================================================
    // PARTE 2 — Tratamento de exceções (validações no construtor e nos setters)
    // =========================================================================
    private static void parte2Excecoes() {
        titulo("PARTE 2 - Exceções: o objeto inválido nem chega a existir");

        // Cada try testa UM erro. O catch mostra a mensagem que a nossa exceção carregou.
        try {
            new Musica("   ", caminho("bohemian.mp3"), "Queen", "");
        } catch (FaixaInvalidaException e) {
            System.out.println("Título vazio      -> " + e.getMessage());
        }

        try {
            new Musica("Texto", caminho("anotacoes.txt"), "", "");
        } catch (FaixaInvalidaException e) {
            System.out.println("Não é .mp3        -> " + e.getMessage());
        }

        try {
            new Musica("Sumiu", caminho("nao_existe.mp3"), "", "");
        } catch (FaixaInvalidaException e) {
            System.out.println("Arquivo inexistente -> " + e.getMessage());
        }

        try {
            new EpisodioPodcast("Ep zero", caminho("ep1.mp3"), "Café com Código", 0);
        } catch (FaixaInvalidaException e) {
            System.out.println("Episódio 0        -> " + e.getMessage());
        }

        try {
            new Playlist("");
        } catch (PlaylistInvalidaException e) {
            System.out.println("Playlist sem nome -> " + e.getMessage());
        }
    }

    // =========================================================================
    // PARTE 3 — Biblioteca e playlists (coleções e associação)
    // =========================================================================
    private static Biblioteca parte3BibliotecaEPlaylists() throws PlayerException {
        titulo("PARTE 3 - Biblioteca, playlists e coleções");

        Biblioteca biblioteca = new Biblioteca();

        // A Biblioteca CRIA as playlists (associação: o objeto nasce dentro do outro).
        Playlist rock = biblioteca.criarPlaylist("Rock");
        Playlist estudos = biblioteca.criarPlaylist("Estudos");

        // Nome repetido (mesmo com maiúsculas diferentes) -> exceção.
        try {
            biblioteca.criarPlaylist("ROCK");
        } catch (PlaylistInvalidaException e) {
            System.out.println("Nome repetido     -> " + e.getMessage());
        }

        // As faixas são criadas FORA e depois adicionadas (associação do outro jeito).
        Musica m1 = new Musica("Bohemian Rhapsody", caminho("bohemian.mp3"), "Queen", "A Night at the Opera");
        Musica m2 = new Musica("Back in Black", caminho("backinblack.mp3"), "AC/DC", "Back in Black");
        EpisodioPodcast ep1 = new EpisodioPodcast("POO na prática", caminho("ep1.mp3"), "Café com Código", 1);
        EpisodioPodcast ep2 = new EpisodioPodcast("Herança e Polimorfismo", caminho("ep2.mp3"), "Café com Código", 2);

        rock.adicionarFaixa(m1);
        rock.adicionarFaixa(m2);

        // A mesma lista aceita Musica E EpisodioPodcast (parâmetro do tipo Faixa).
        estudos.adicionarFaixa(ep1);
        estudos.adicionarFaixa(ep2);
        estudos.adicionarFaixa(m1);    // a mesma música pode estar em duas playlists

        // Regra: sem duplicatas. adicionarFaixa devolve false e não adiciona.
        boolean adicionou = rock.adicionarFaixa(m1);
        System.out.println("Adicionar m1 de novo no Rock? " + adicionou);

        // buscarPorNome ignora maiúsculas/minúsculas.
        System.out.println("Buscar \"estudos\": " + biblioteca.buscarPorNome("estudos"));
        System.out.println("Buscar \"Jazz\":    " + biblioteca.buscarPorNome("Jazz"));

        // Posição na lista e acesso por índice (ArrayList: indexOf e get).
        System.out.println("Posição de \"Back in Black\" no Rock: " + rock.indexOf(m2));
        System.out.println("Faixa na posição 0 do Rock: " + rock.getFaixa(0).getTitulo());

        // Percorrendo a coleção de playlists com for-each.
        System.out.println("\nPlaylists da biblioteca:");
        for (Playlist p : biblioteca.getPlaylists()) {
            System.out.println("  " + p);          // toString() da Playlist: "Rock (2)"
        }
        System.out.println("Total de faixas: " + biblioteca.getTotalFaixas());

        return biblioteca;
    }

    // =========================================================================
    // PARTE 4 — Polimorfismo
    // =========================================================================
    private static void parte4Polimorfismo(Biblioteca biblioteca) {
        titulo("PARTE 4 - Polimorfismo: mesma chamada, respostas diferentes");

        Playlist estudos = biblioteca.buscarPorNome("Estudos");

        // A variável "f" é do tipo Faixa (abstrata), mas cada objeto é uma Musica
        // ou um EpisodioPodcast. O Java chama a versão da CLASSE REAL de cada um.
        for (Faixa f : estudos.getFaixas()) {
            f.registrarReproducao();   // método herdado (igual para todos)
            System.out.println("Tipo: " + f.getTipo()
                    + " | Descrição: " + f.getDescricao()
                    + " | Tocada " + f.getVezesTocadas() + "x");
        }
    }

    // =========================================================================
    // PARTE 5 — Sobrescrita: o podcast lembra a posição, a música não
    // =========================================================================
    private static void parte5PosicaoDoPodcast(Biblioteca biblioteca) {
        titulo("PARTE 5 - Sobrescrita: registrarPosicao / getPosicaoInicial");

        Playlist estudos = biblioteca.buscarPorNome("Estudos");

        // Simula: o usuário ouviu cada faixa por 125 segundos e pausou.
        for (Faixa f : estudos.getFaixas()) {
            f.registrarPosicao(125);
        }

        // Ao voltar, de onde cada uma recomeça?
        for (Faixa f : estudos.getFaixas()) {
            System.out.println(f.getTitulo() + " recomeça em " + f.getPosicaoInicial() + "s");
        }
        // Podcast: 125.0 (EpisodioPodcast SOBRESCREVEU os dois métodos)
        // Música:  0.0   (usa o comportamento padrão herdado da Faixa)

        // Registrar de novo SUBSTITUI a posição (não soma).
        Faixa ep1 = estudos.getFaixa(0);
        ep1.registrarPosicao(300);
        System.out.println("\nDepois de ouvir até 300s: " + ep1);   // mostra "Parou em 5:00"
    }

    // =========================================================================
    // PARTE 6 — Encapsulamento da lista
    // =========================================================================
    private static void parte6EncapsulamentoDaLista(Biblioteca biblioteca) {
        titulo("PARTE 6 - Encapsulamento: getFaixas() devolve uma CÓPIA");

        Playlist rock = biblioteca.buscarPorNome("Rock");

        ArrayList<Faixa> copia = rock.getFaixas();
        copia.clear();   // apaga só a cópia!

        System.out.println("Tamanho da cópia depois do clear(): " + copia.size());
        System.out.println("Tamanho real da playlist Rock:      " + rock.getTamanho());

        // Remover: só pelo método da classe.
        Faixa primeira = rock.getFaixa(0);
        rock.removerFaixa(primeira);
        System.out.println("Depois de removerFaixa: " + rock + " -> está vazia? " + rock.isVazia());
    }

    // =========================================================================
    // AUXILIARES
    // =========================================================================

    /** Cria a pasta e os arquivos .mp3 vazios usados no exemplo. */
    private static void prepararArquivosDeTeste() throws IOException {
        File pasta = new File(PASTA);
        pasta.mkdirs();
        String[] nomes = {"bohemian.mp3", "backinblack.mp3", "seminfo.mp3", "ep1.mp3", "ep2.mp3", "anotacoes.txt"};
        for (String nome : nomes) {
            new File(pasta, nome).createNewFile();   // não faz nada se já existir
        }
    }

    private static String caminho(String nomeArquivo) {
        return PASTA + File.separator + nomeArquivo;
    }

    private static void titulo(String texto) {
        System.out.println("\n========== " + texto + " ==========");
    }
}
